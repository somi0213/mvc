import{ Component} from '@angular/core';

@Component ({
    selector: 'contact',
    templateUrl : './contact.component.html',
    styleUrls :['./contact.component.css']

})

export class ContactComponent{
     imgHeight : number = 1000;
 imgWidth : number = 2000;
}