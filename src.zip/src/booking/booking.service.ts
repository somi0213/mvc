import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


import {IBooking} from "./booking"
 
 import { Observable, throwError } from 'rxjs';
 import {tap, catchError} from 'rxjs/operators';



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

//@Injectable()
@Injectable({
    providedIn: 'root'
})
export class BookingService {

  constructor(private http:HttpClient) {}

  private userUrl = 'http://localhost:9080/booking/';  
	private bookingUrl = '/booking';

  public getBooking() {
    return this.http.get<IBooking[]>(this.bookingUrl);
  }

//   public deleteUser(user) {
//     return this.http.delete(this.userUrl + "/"+ user.id);
//   }

   public save(booking) {
    return this.http.post<IBooking>(this.bookingUrl, booking);
  }
  

}

// import { Injectable } from "@angular/core";
// //import {IBooking} from "./booking"
// import { HttpClient,HttpErrorResponse } from '@angular/common/http';
// import { Observable, throwError } from 'rxjs';
// import {tap, catchError} from 'rxjs/operators';
// import { IBooking } from "./booking";

// @Injectable({
//     providedIn : 'root'
// })
   
// export class BookingService{
   

//    // featureurl = 'http://localhost:9080/booking'
//     bookingurl='/booking';
//     constructor(private httpSer:HttpClient) {}
//     //  public getBooking() {
// 	//     return this.httpSer.get<IBooking[]>(this.bookingurl);
// 	//   }
	 
// 	 public createBooking(booking) {
// 		    return this.httpSer.post<IBooking[]>(this.bookingurl, booking);
// 		  }
    
//     // getPlace() : Observable<IPlace[]>{

//     // }

// getTicket():Observable<IBooking[]>{
    
//         return this.httpSer.get<IBooking[]>("//localhost:9080/booking").pipe(
            
//         tap(data => console.log('booking : '+JSON.stringify(data))),
//         //catchError(this.handleError)
//         catchError(this.handleErrorObservable)
//             );
//   }
    

// // private handleError(err:HttpErrorResponse){
// //         let errorMessage = '';
// //         if (err.error instanceof ErrorEvent) {
// //           errorMessage = `An error occurred: ${err.error.message}`;
// //         } else {
// //           errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
// //         }
// //         //console.error(errorMessage);
// //         return throwError(errorMessage);
       
    

//     private extractData(res: Response) 
//     {
//         let body = res.json();              
//         return body;
//     }

//     private handleErrorObservable (error: Response | any) 
//     {   
//         return throwError(error.message || error);
//     }

//     //  public createUser(booking) {
//     //     return this.httpSer.post<IBooking>("//localhost:9080/features", features);
//     //   }
// }

