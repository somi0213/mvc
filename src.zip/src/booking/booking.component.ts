import { Component, OnInit } from '@angular/core';
import { IBooking } from "src/booking/booking";
import { BookingService } from "src/booking/booking.service";
import {FormControl,FormGroup, Validator, ValidationErrors} from '@angular/forms';  
@Component ({
    selector: 'booking',
    templateUrl : './booking.component.html',
   // styleUrls :['./Home.component.css']

})

//export class BookingComponent {
//    errorMessage:string;

  
//     booking : IBooking[]= []; 
//  constructor(private bookingservice:BookingService) {
//   console.log("At constructor ");
 
//}
//ngOnInit(): void {
//  this.featureservice.getPlace().subscribe(
//   places =>{
//   this.places = places;
 // this.searchedMovies = this.movies;
//}
//error =>this.errorMessage = error
export class BookingComponent implements OnInit {  
  
  constructor(private bookingservice:BookingService) { }  
  
  booking : IBooking=new IBooking();  
  submitted = false;  
  
  ngOnInit() {  
    this.submitted=false;  
  }  //
  saveBooking(saveBooking){  
    this.booking=new IBooking();     
    this.booking.userName=this.userName.value;  
    this.booking.Password=this.Password.value;  
    this.booking.Email=this.Email.value;  
    this.booking.Number=this.Number.value;  
    this.submitted = true;  
    this.save();  
  }  
   studentsaveform=new FormControl({  
  
  });  
    
  
  save() {  
    this.bookingservice.save(this.booking)  
      .subscribe(data => console.log(data), error => console.log(error));  
    this.booking = new IBooking();  
  }  
  
  get userName(){  
    return this.studentsaveform.get('userName');  
  }  
  
  get Password(){  
    return this.studentsaveform.get('Password');  
  }  
  
  get Email(){  
    return this.studentsaveform.get('Email');  
  }  
  get Number(){  
    return this.studentsaveform.get('Number');  
  }  
  
  addStudentForm(){  
    this.submitted=false;  
    this.studentsaveform.reset();  
  }  
}  
  











//   ngOnChanges(): void {

//   console.log("At the Change detection phase!");  
//   }
//   ngOnDestroy(): void {
//     console.log("Destroying the component");
//   }

// }