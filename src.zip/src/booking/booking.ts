export class IBooking{

     userName:number;
    Password:string;
  Email:string;
    Number:number;
}