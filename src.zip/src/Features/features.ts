export interface IPlace{

    placeID:number;
    placeName:string;
  Description:string;
    package:number;
   // placeImg:string;
   // rating : number;
}