import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { TravelComponent } from './../Travel/Travel.component';
import { UserComponent } from './../User/user.component';
import { HomeComponent } from './../Home/Home.component';
import { FeaturesComponent } from './../Features/features.component';
import { ContactComponent } from './../contact/contact.component';
import { ErrorComponent } from './../error/error.component';
import { RegisterComponent } from './../register/register.component';
import { HttpClientModule } from "@angular/common/http";
import { BookingComponent } from "../booking/booking.component";



@NgModule({
  declarations: [
    AppComponent, UserComponent,HomeComponent,FeaturesComponent,ContactComponent,ErrorComponent,RegisterComponent,BookingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
 
  FormsModule,
  ReactiveFormsModule,
  FormsModule
  
  
  


  

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
